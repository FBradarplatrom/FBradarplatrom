const sleep = ms => new Promise(r => setTimeout(r, ms));
const cfg = async () => (await chrome.storage.local.get('cfg')).cfg || {};
const status = t => chrome.storage.local.set({ status: t });
const H = c => ({ 'content-type': 'application/json', 'x-api-key': c.apiKey });

// تُحقن داخل صفحة نتائج الأداة؛ تعتمد على المحددات (CSS selectors) من الإعدادات
function scrape(c) {
  const t = (el, s) => { const x = s && el.querySelector(s); return x ? x.textContent.trim() : ''; };
  const n = v => +String(v).replace(/[^\d.]/g, '') || 0;
  return [...document.querySelectorAll(c.card)].slice(0, c.max || 20).map(el => ({
    name: t(el, c.title), eng: n(t(el, c.eng)), ads: n(t(el, c.ads)),
    country: t(el, c.country), url: (el.querySelector(c.link) || {}).href || ''
  })).filter(x => x.name);
}
const loaded = id => new Promise(r => {
  const f = (i, info) => { if (i === id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(f); r(); } };
  chrome.tabs.onUpdated.addListener(f); setTimeout(r, 30000);
});

async function runAll() {
  const c = await cfg();
  if (!c.server || !c.apiKey) throw new Error('أدخل عنوان الخادم والمفتاح في الإعدادات');
  const res = await fetch(c.server.replace(/\/$/, '') + '/api/ext/seeds', { headers: H(c) });
  if (!res.ok) throw new Error('تعذّر جلب المنتجات من المنصة (' + res.status + ')');
  const seeds = await res.json();
  if (!seeds.length) throw new Error('لا توجد منتجات رابحة في المنصة بعد. حلّل بيانات المكتبة أولاً أو احفظ منتجات.');
  const keep = setInterval(() => chrome.runtime.getPlatformInfo(), 20000); // يبقي العامل نشطاً
  try {
    for (const tool of c.tools || []) {
      const items = []; let i = 0;
      for (const sd of seeds) {
        await status(`${tool.name}: ${++i}/${seeds.length} ${sd.keyword}`);
        const tab = await chrome.tabs.create({ url: tool.searchUrl.replace('{q}', encodeURIComponent(sd.keyword)), active: false });
        await loaded(tab.id); await sleep(tool.waitMs || 4000);
        try {
          const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scrape, args: [tool] });
          (r.result || []).forEach(x => items.push({ ...x, seed: sd.name, tool: tool.name }));
        } catch (e) { /* صلاحية ناقصة أو صفحة لم تُحمَّل */ }
        chrome.tabs.remove(tab.id); await sleep(tool.delayMs || 2500);
      }
      if (items.length) {
        const p = await fetch(c.server.replace(/\/$/, '') + '/api/ext/spy', { method: 'POST', headers: H(c), body: JSON.stringify({ tool: tool.name, items }) });
        await status(`${tool.name}: أُرسلت ${items.length} نتيجة (${p.ok ? 'نجاح' : 'فشل ' + p.status})`);
      } else await status(`${tool.name}: لا نتائج. راجع المحددات`);
    }
    await status('انتهى التشغيل');
  } finally { clearInterval(keep); }
}
chrome.runtime.onMessage.addListener((m, _s, reply) => {
  if (m.cmd === 'run') runAll().catch(e => status('خطأ: ' + e.message));
  reply({ ok: 1 });
});
