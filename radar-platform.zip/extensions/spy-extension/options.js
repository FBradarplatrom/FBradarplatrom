const $ = i => document.getElementById(i);
const TEMPLATE = [{
  name: 'مثال: اسم الأداة',
  searchUrl: 'https://example-spy-tool.com/search?q={q}',
  card: '.result-card', title: '.title', eng: '.engagement', ads: '.ads-count', country: '.country', link: 'a',
  waitMs: 4000, delayMs: 2500, max: 20
}];
(async () => {
  const { cfg = {} } = await chrome.storage.local.get('cfg');
  $('server').value = cfg.server || ''; $('apiKey').value = cfg.apiKey || '';
  $('tools').value = JSON.stringify(cfg.tools || TEMPLATE, null, 2);
})();
$('save').onclick = async () => {
  try {
    const tools = JSON.parse($('tools').value);
    const origins = [...new Set(tools.map(t => new URL(t.searchUrl.replace('{q}', 'x')).origin + '/*'))];
    const ok = await chrome.permissions.request({ origins });
    await chrome.storage.local.set({ cfg: { server: $('server').value.trim(), apiKey: $('apiKey').value.trim(), tools } });
    $('s').textContent = ok ? 'تم الحفظ ومنح الصلاحيات.' : 'تم الحفظ، لكن الصلاحيات لم تُمنح فلن تعمل القراءة.';
  } catch (e) { $('s').textContent = 'خطأ في الإعدادات: ' + e.message; }
};
$('run').onclick = () => chrome.runtime.sendMessage({ cmd: 'run' });
chrome.storage.onChanged.addListener(c => { if (c.status) $('s').textContent = c.status.newValue; });
