'use strict';
// قسم «ثغرات السوق الجزائري»: منتج رابح في سوق أجنبي (من المحفوظات) ← هل يُعلَن عنه في الجزائر؟
// 1) عبارات بحث جزائرية (ذكاء اصطناعي إن وُجد OPENAI_API_KEY، وإلا كتابة يدوية)
// 2) الإضافة تبحث في مكتبة إعلانات ميتا (الجزائر، النشطة والمتوقفة) والصفحة تقارن لحظياً (بصمة الصورة، رابط المورّد، الكلمات المميزة)
// 3) الحكم: ثغرة مؤكدة · منافسة ضعيفة · جُرّب وتوقف · مشبع · يحتاج تحققك · غير حاسم. والثغرات تُراقَب أسبوعياً.
const C = require('./core.js');

const ENV = (k, d) => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : d);
const WEEK = 7 * 864e5;
const VERDICTS = ['new', 'gap', 'weak', 'tried', 'saturated', 'check', 'inconclusive'];

module.exports = function mountGap(app, X) {
  const { db, auth, active, wrap, now } = X;
  const bad = (m, code) => Object.assign(new Error(m), { status: code || 400 });
  const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };
  const str = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n);

  db.exec(`
create table if not exists gap_products(id integer primary key, user_id integer, k text, name text, snap text, terms text, keywords text, hashes text,
  verdict text default 'new', stats text, watch integer default 1, created_at integer, last_scan_at integer, next_check_at integer, unique(user_id, k));
create table if not exists gap_scans(id integer primary key, gp_id integer, user_id integer, started_at integer, finished_at integer, queries text, scanned integer default 0, seen text);
create table if not exists gap_matches(id integer primary key, gp_id integer, user_id integer, ad_id text, scan_id integer, row text, ev text, level text, decision text,
  created_at integer, unique(gp_id, ad_id));
create index if not exists gap_m_gp on gap_matches(gp_id);`);
  // أدوات التجسس حُذفت نهائياً: نتائجها القديمة لا تبقى في الأرشيف
  try { db.prepare("delete from runs where source='spy'").run(); } catch (e) {}

  const own = (uid, id) => { const p = db.prepare('select * from gap_products where id=? and user_id=?').get(+id, uid); if (!p) throw bad('غير موجود', 404); return p; };
  const view = p => ({
    id: p.id, k: p.k, name: p.name, snap: J(p.snap, {}), terms: J(p.terms, []), keywords: J(p.keywords, []), hashes: J(p.hashes, []), verdict: p.verdict,
    stats: J(p.stats, {}), watch: !!p.watch, created_at: p.created_at, last_scan_at: p.last_scan_at, next_check_at: p.next_check_at,
    due: !!(p.watch && p.next_check_at && p.next_check_at <= now())
  });
  const matchesOf = gp => db.prepare('select id,ad_id,scan_id,row,ev,level,decision,created_at from gap_matches where gp_id=? order by id desc').all(gp)
    .map(m => ({ id: m.id, ad_id: m.ad_id, scan_id: m.scan_id, row: J(m.row, {}), ev: J(m.ev, {}), level: m.level, decision: m.decision || '', created_at: m.created_at }));

  /* ---------- الحكم ---------- */
  function verdictOf(gp) {
    const ms = matchesOf(gp.id), last = db.prepare('select * from gap_scans where gp_id=? and finished_at is not null order by id desc limit 1').get(gp.id);
    const yes = ms.filter(m => m.decision === 'yes' || (m.level === 'strong' && m.decision !== 'no'));
    const maybe = ms.filter(m => m.level === 'possible' && !m.decision);
    const sellers = new Set(yes.map(m => m.row.page_id || m.row.page_name || m.ad_id));
    const act = yes.filter(m => m.row.status !== 'inactive');
    const actSellers = new Set(act.map(m => m.row.page_id || m.row.page_name || m.ad_id));
    const qs = last ? J(last.queries, []) : [], done = qs.filter(q => q.status === 'done').length;
    const firstSeen = act.map(m => m.row.start_date).filter(Boolean).sort()[0] || '';
    const stats = { matches: yes.length, possible: maybe.length, sellers: sellers.size, activeSellers: actSellers.size, active: act.length, scanned: last ? last.scanned : 0,
      queries: qs.length, queriesDone: done, firstSeen, scans: db.prepare('select count(*) n from gap_scans where gp_id=? and finished_at is not null').get(gp.id).n };
    let v = 'new';
    if (last) {
      if (!yes.length) v = maybe.length ? 'check' : done >= 2 ? 'gap' : 'inconclusive';
      else if (!act.length) v = 'tried';
      else if (actSellers.size <= 2) v = 'weak';
      else v = 'saturated';
    }
    return { v, stats };
  }
  function refresh(gp) {
    const { v, stats } = verdictOf(gp);
    db.prepare('update gap_products set verdict=?, stats=? where id=?').run(v, JSON.stringify(stats), gp.id);
    return own(gp.user_id, gp.id);
  }

  /* ---------- القائمة ---------- */
  app.get('/api/gap', auth, active, wrap((q, s) => {
    const ps = db.prepare('select * from gap_products where user_id=? order by created_at desc').all(q.u.id).map(view);
    s.json({ products: ps, ai: !!ENV('OPENAI_API_KEY', ''), due: ps.filter(p => p.due).length });
  }));
  app.get('/api/gap/due', auth, active, wrap((q, s) => s.json({ due: db.prepare('select count(*) n from gap_products where user_id=? and watch=1 and next_check_at<=?').get(q.u.id, now()).n })));
  app.get('/api/gap/:id', auth, active, wrap((q, s) => { const p = own(q.u.id, q.params.id); s.json(Object.assign(view(p), { matches: matchesOf(p.id) })); }));

  // من «المحفوظات» إلى القسم: نسخة من المنتج كما حُفظ (الاسم، الصور، روابط المورّد، نصوص الإعلانات الأجنبية)
  app.post('/api/gap', auth, active, wrap((q, s) => {
    const k = str(q.body && q.body.k, 300); if (!k) throw bad('k');
    const sv = db.prepare('select snap from saved where user_id=? and k=?').get(q.u.id, k);
    if (!sv) throw bad('المنتج غير موجود في المحفوظات', 404);
    const old = db.prepare('select id from gap_products where user_id=? and k=?').get(q.u.id, k);
    if (old) return s.json({ id: old.id, existed: true });
    const p = J(sv.snap, {}), recs = (p.recs || []).slice(0, 12);
    const ads = recs.map(r => r.a || {}).concat(p.top ? [p.top] : []);
    const uniq = a => [...new Set(a.filter(Boolean))];
    const snap = {
      name: str(p.name, 200), kw: str(p.kw, 120), cat: p.cat || p.tier || '', score: p.score || 0, n: p.n || 0, price: p.pr || p.price || 0,
      images: uniq((p.images || []).concat(ads.map(a => a.image_url))).slice(0, 8),
      links: uniq(ads.map(a => a.link_url)).slice(0, 8), lib: p.lib || (p.top && p.top.library_url) || '',
      country: uniq(ads.map(a => a.country))[0] || '',
      texts: uniq(ads.map(a => str([a.title, a.body].filter(Boolean).join(' — '), 600))).slice(0, 4), tags: (p.tags || []).slice(0, 3)
    };
    const id = db.prepare('insert into gap_products(user_id,k,name,snap,terms,keywords,hashes,stats,created_at) values(?,?,?,?,?,?,?,?,?)')
      .run(q.u.id, k, snap.name || 'منتج', JSON.stringify(snap), '[]', '[]', '[]', '{}', now()).lastInsertRowid;
    s.json({ id: Number(id) });
  }));
  app.delete('/api/gap/:id', auth, active, wrap((q, s) => {
    const p = own(q.u.id, q.params.id);
    ['gap_matches', 'gap_scans'].forEach(t => db.prepare(`delete from ${t} where gp_id=?`).run(p.id));
    db.prepare('delete from gap_products where id=?').run(p.id); s.json({ ok: 1 });
  }));
  // العبارات والكلمات المميزة وبصمات الصور والمراقبة
  const cleanTerms = a => (Array.isArray(a) ? a : []).slice(0, 12).map(t => ({ q: str(t && t.q, 100), lang: ['ar', 'dz', 'fr', 'arz', 'en'].includes(t && t.lang) ? t.lang : 'ar' })).filter(t => t.q);
  const cleanWords = a => [...new Set((Array.isArray(a) ? a : []).map(w => str(w, 40)).filter(w => w.length >= 2))].slice(0, 30);
  app.put('/api/gap/:id', auth, active, wrap((q, s) => {
    const p = own(q.u.id, q.params.id), b = q.body || {};
    if (b.terms) db.prepare('update gap_products set terms=? where id=?').run(JSON.stringify(cleanTerms(b.terms)), p.id);
    if (b.keywords) db.prepare('update gap_products set keywords=? where id=?').run(JSON.stringify(cleanWords(b.keywords)), p.id);
    if (Array.isArray(b.hashes)) db.prepare('update gap_products set hashes=? where id=?').run(JSON.stringify(b.hashes.filter(h => /^[0-9a-f]{16}$/.test(h)).slice(0, 30)), p.id);
    if (b.watch !== undefined) db.prepare('update gap_products set watch=? where id=?').run(b.watch ? 1 : 0, p.id);
    s.json(view(own(q.u.id, p.id)));
  }));

  /* ---------- اقتراح العبارات الجزائرية بالذكاء الاصطناعي ---------- */
  async function aiTerms(snap) {
    const key = ENV('OPENAI_API_KEY', ''); if (!key) return null;
    const base = ENV('OPENAI_BASE_URL', 'https://api.openai.com/v1').replace(/\/+$/, '');
    const models = [...new Set([ENV('OPENAI_MODEL', ''), 'gpt-4.1-mini', 'gpt-4o-mini'].filter(Boolean))];
    const sys = 'You help an Algerian e-commerce researcher check whether a product that sells abroad is already advertised in Algeria on the Facebook Ad Library. ' +
      'Algerian advertisers write in Modern Standard Arabic, Algerian Darija (Arabic script), French, and sometimes Arabizi. Return ONLY JSON.';
    const user = 'Product (from a foreign ' + (snap.country || '') + ' ad):\nName: ' + snap.name + '\nKeyword: ' + snap.kw + '\nAd texts:\n- ' + (snap.texts || []).join('\n- ') +
      '\n\nReturn JSON {"name_ar":"","name_fr":"","queries":[{"q":"","lang":"ar|dz|fr|arz"}],"keywords":[""]}.\n' +
      'queries: 5 short searches (1-4 words) the way an Algerian seller would name or advertise THIS product: the generic product name in Arabic, in French, in Darija, and 1-2 phrases with its main benefit. No brand names unless the product is known by it. ' +
      'keywords: 8-14 distinctive words (Arabic and French) that would appear in an Algerian ad for this exact product (type, material, key feature), not generic words like "جودة" or "livraison".';
    let lastErr = '';
    for (const model of models) {
      try {
        const r = await fetch(base + '/chat/completions', {
          method: 'POST', signal: AbortSignal.timeout(25000),
          headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key },
          body: JSON.stringify({ model, response_format: { type: 'json_object' }, temperature: 0.2, messages: [{ role: 'system', content: sys }, { role: 'user', content: user }] })
        });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) { lastErr = (j.error && j.error.message) || ('HTTP ' + r.status); if (r.status === 401) break; continue; }
        const o = J(j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content, null);
        if (!o) { lastErr = 'رد غير مفهوم'; continue; }
        const terms = cleanTerms(o.queries);
        return { terms, keywords: cleanWords([].concat(o.keywords || [], o.name_ar ? [o.name_ar] : [], o.name_fr ? [o.name_fr] : [])), model };
      } catch (e) { lastErr = e.name === 'TimeoutError' ? 'انتهت مهلة الذكاء الاصطناعي' : e.message; }
    }
    throw bad('تعذّر اقتراح العبارات: ' + lastErr, 502);
  }
  app.post('/api/gap/:id/suggest', auth, active, (q, s, n) => {
    let p; try { p = own(q.u.id, q.params.id); } catch (e) { return n(e); }
    aiTerms(J(p.snap, {})).then(r => {
      if (!r) return s.json({ ai: false });
      db.prepare('update gap_products set terms=?, keywords=? where id=?').run(JSON.stringify(r.terms), JSON.stringify(r.keywords), p.id);
      s.json(Object.assign({ ai: true }, r));
    }).catch(n);
  });

  /* ---------- الفحص ---------- */
  app.post('/api/gap/:id/scan', auth, active, wrap((q, s) => {
    const p = own(q.u.id, q.params.id), qs = cleanTerms(q.body && q.body.queries).map(t => ({ q: t.q, lang: t.lang, status: 'pending', seen: 0 }));
    if (!qs.length) throw bad('اكتب عبارة بحث واحدة على الأقل');
    const id = db.prepare('insert into gap_scans(gp_id,user_id,started_at,queries,seen) values(?,?,?,?,?)').run(p.id, q.u.id, now(), JSON.stringify(qs), '[]').lastInsertRowid;
    s.json({ scan: Number(id) });
  }));
  // إعلانات جزائرية من الإضافة → صفوف موحّدة تعود للصفحة لتقارنها (الصورة تُقارن في المتصفح)
  app.post('/api/gap/:id/ingest', auth, active, wrap((q, s) => {
    const p = own(q.u.id, q.params.id), b = q.body || {};
    const sc = db.prepare('select * from gap_scans where id=? and gp_id=?').get(+b.scan, p.id); if (!sc) throw bad('scan', 404);
    if (!Array.isArray(b.ads) || b.ads.length > 400) throw bad('ads');
    const seen = new Set(J(sc.seen, [])), rows = [], t = now();
    for (const raw of b.ads) {
      let r = null; try { r = C.rowFromRaw(raw, { query: str(b.query, 120), niche: '', country: 'DZ', src: raw && raw._src === 'dom' ? 'dom' : 'net' }, t); } catch (e) {}
      if (!r || seen.has(r.ad_id)) continue;
      seen.add(r.ad_id);
      rows.push({ ad_id: r.ad_id, library_url: r.library_url, page_id: r.page_id, page_name: r.page_name, status: r.status, start_date: r.start_date, days_running: r.days_running,
        title: r.title, body: r.body.slice(0, 1500), link_url: r.link_url, domain: r.domain, image_url: r.image_url, video_url: r.video_url, duplicates: r.duplicates, search: r.search });
    }
    db.prepare('update gap_scans set seen=?, scanned=? where id=?').run(JSON.stringify([...seen].slice(-5000)), seen.size, sc.id);
    s.json({ rows, scanned: seen.size });
  }));
  app.post('/api/gap/:id/matches', auth, active, wrap((q, s) => {
    const p = own(q.u.id, q.params.id), b = q.body || {};
    const up = db.prepare(`insert into gap_matches(gp_id,user_id,ad_id,scan_id,row,ev,level,created_at) values(?,?,?,?,?,?,?,?)
      on conflict(gp_id,ad_id) do update set row=excluded.row, ev=excluded.ev, scan_id=excluded.scan_id,
      level=case when excluded.level='strong' then 'strong' else gap_matches.level end`);
    let n = 0;
    for (const m of (Array.isArray(b.matches) ? b.matches : []).slice(0, 200)) {
      if (!m || !m.row || !m.row.ad_id || !['strong', 'possible'].includes(m.level)) continue;
      const row = {}; ['ad_id', 'library_url', 'page_id', 'page_name', 'status', 'start_date', 'days_running', 'title', 'body', 'link_url', 'domain', 'image_url', 'video_url', 'duplicates', 'search']
        .forEach(k => { row[k] = m.row[k] == null ? '' : typeof m.row[k] === 'number' ? m.row[k] : str(m.row[k], k === 'body' ? 1500 : 1200); });
      up.run(p.id, q.u.id, String(row.ad_id), +b.scan || 0, JSON.stringify(row), JSON.stringify(m.ev || {}).slice(0, 2000), m.level, now()); n++;
    }
    const v = view(refresh(p)); s.json({ saved: n, verdict: v.verdict, stats: v.stats });
  }));
  app.post('/api/gap/:id/finish', auth, active, wrap((q, s) => {
    const p = own(q.u.id, q.params.id), b = q.body || {};
    const sc = db.prepare('select * from gap_scans where id=? and gp_id=?').get(+b.scan, p.id); if (!sc) throw bad('scan', 404);
    const qs = J(sc.queries, []), st = Array.isArray(b.items) ? b.items : [];
    qs.forEach(x => { const it = st.find(i => i && i.q === x.q); if (it) { x.status = ['done', 'timeout', 'skipped', 'stopped'].includes(it.status) ? it.status : 'stopped'; x.seen = +it.seen || 0; } });
    db.prepare('update gap_scans set finished_at=?, queries=? where id=?').run(now(), JSON.stringify(qs), sc.id);
    db.prepare('update gap_products set last_scan_at=?, next_check_at=? where id=?').run(now(), now() + WEEK, p.id);
    s.json(Object.assign(view(refresh(p)), { matches: matchesOf(p.id) }));
  }));
  // تحققك اليدوي: هذا هو المنتج نفسه / ليس هو
  app.put('/api/gap/:id/matches/:mid', auth, active, wrap((q, s) => {
    const p = own(q.u.id, q.params.id), d = q.body && q.body.decision;
    db.prepare('update gap_matches set decision=? where id=? and gp_id=?').run(['yes', 'no'].includes(d) ? d : null, +q.params.mid, p.id);
    s.json(view(refresh(p)));
  }));

  return { verdictOf, VERDICTS };
};
